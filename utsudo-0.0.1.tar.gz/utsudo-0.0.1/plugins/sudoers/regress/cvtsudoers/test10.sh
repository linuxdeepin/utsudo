#!/bin/sh
#
# Test command defaults filtering
#

./cvtsudoers -c "" -f sudoers -s aliases,privileges -d command $TESTDIR/sudoers

exit 0
